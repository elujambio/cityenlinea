$(document).ready(function(){
	Sequency(); 
});